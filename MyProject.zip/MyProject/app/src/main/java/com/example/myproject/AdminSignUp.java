package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;

import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminSignUp extends AppCompatActivity {
   EditText txtTitle;
   EditText txtDescription;
   EditText txtPrice;


   private FirebaseDatabase mFirebaseDatabase;
   private DatabaseReference mDatabaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal);

        mFirebaseDatabase=FirebaseDatabase.getInstance();
        mDatabaseReference=mFirebaseDatabase.getReference().child("TravelDeals");

        txtTitle=findViewById(R.id.txtTitle);
        txtDescription=findViewById(R.id.txtDescription);
        txtPrice=findViewById(R.id.txtPrice);
    }
    @Override
    public boolean onCreateOptionMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.save_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()) {
            case R.id.save_menu:
                saveDeal();
                Toast.makeText(this, "Deal Saved", Toast.LENGTH_LONG).show();
                clean();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
        }
        private void saveDeal() {
            String title=txtTitle.getText().toString();
            String description=txtDescription.getText().toString();
            String price=txtPrice.getText().toString();
            TravelDeals deal=new TravelDeals(title,description,price,imageUrl:" ");
            mDatabaseReference.push().setValue(deal);
        }
        private void clean(){
         txtTitle.setText("");
         txtPrice.setText("");
         txtDescription.setText("");
         txtTitle.requestFocus();
        }
    }

