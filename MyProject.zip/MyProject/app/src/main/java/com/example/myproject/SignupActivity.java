package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignupActivity extends AppCompatActivity {
    public FirebaseDatabase mFirebaseDatabase;
    public DatabaseReference mDatabaseReference;
    public EditText email;
    public EditText firstLastName;
    public EditText password;
    public Button btnSave;
    private String emails;
    private String names;
    private String pword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = findViewById(R.id.editTextEmail);
                firstLastName = findViewById(R.id.editTextNames);
                password = findViewById(R.id.editTextPassword);
                setEmails(email.getText().toString());
                setNames(firstLastName.getText().toString());
                setPword(password.getText().toString());
                FirebaseDatabase mFirebaseDatabase = FirebaseDatabase.getInstance();
                DatabaseReference mDatabaseReference = mFirebaseDatabase.getReference("UserSignUp");
                mDatabaseReference.setValue(getEmails());
                mDatabaseReference.setValue(getNames());
                mDatabaseReference.setValue(getPword());
            }
        });

    }
        public String getEmails () {
            return emails;
        }

        public void setEmails (String emails){
            this.emails = emails;
        }

        public String getNames () {
            return names;
        }

        public void setNames (String names){
            this.names = names;
        }

        public String getPword () {
            return pword;
        }

        public void setPword (String pword){
            this.pword = pword;
        }
    }
